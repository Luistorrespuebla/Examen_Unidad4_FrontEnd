import { createContext } from "react";

const Contexto = createContext(null);

export default Contexto;
