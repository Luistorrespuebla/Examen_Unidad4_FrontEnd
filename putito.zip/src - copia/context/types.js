const types = {
    login:"login",
    logout:"logout"
}

export default types;